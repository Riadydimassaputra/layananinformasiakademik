<?php 

session_start();
unset($_SESSION['idsppapp']);
header("location: ../");


 ?>