<?php 
	
	if (empty($_SESSION['idsppapp']) AND empty($_SESSION['idsppapp'])) {
		header("location: ../");
	}
	


 ?>