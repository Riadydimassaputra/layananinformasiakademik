<?php include 'comp/header.php'; ?>
<?php

if (isset($_POST['simpan'])) {
  insert_jurnal();
}

if (isset($_POST['hapus'])) {
  hapus_jurnal();
}

if (isset($_POST['edit'])) {
  edit_jurnal();
}

?>
<div class="main-content mb-1">
  <div class="section__content section__content--p30">

  </div>
  <div class="content-wrapper">
    <div class="content-header mr-2">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h3 class="col-sm-6 ml-5">Data Jurnal</h3>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="index.php?m=awal">Home</a></li>
            <li class="breadcrumb-item active">Jurnal</li>
          </ol>
        </div><!-- /.col -->
      </div>
    </div>


    <!-- Main Content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12"><br>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary mb-5 ml-5" data-toggle="modal" data-target="#exampleModal">
              Tambah Data Jurnal
            </button>



            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data Jurnal</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <label>Kelas </label>
                        <select name="nama_kelas">
                          <?php
                          $Que = "select kelas.* from kelas";
                          $myQry = mysqli_query($koneksi, $Que) or die("Gagal Query Sub Kelas" . mysqli_error($koneksi));
                          while ($hasil = mysqli_fetch_array($myQry)) {
                            echo "<option value='$hasil[nama_kelas]'>
                      $hasil[nama_kelas]
                </option>";
                          }
                          ?>
                        </select>
                      </div>

                      <div class="form-group">
                        <label>Jurusan</label>
                        <select name="jurusan" class="form-control">
                          <option value="">---PILIH JURUSAN---</option>
                          <option value="TKJ">TKJ</option>
                          <option value="MM">MM</option>
                          <option value="OTKP">OTKP</option>
                          <option value="TBSM">TBSM</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label>Semester</label>
                        <input type="text" class="form-control" autocomplete="off" name="semester" value="S2023/2024 Ganjil">
                      </div>

                      <div class="form-group">
                        <label>Hari</label>
                        <select name="hari" class="form-control">
                          <option value="">---PILIH HARI---</option>
                          <option value="Senin">SENIN</option>
                          <option value="Selasa">SELASA</option>
                          <option value="Rabu">RABU</option>
                          <option value="Kamis">KAMIS</option>
                          <option value="Jumat">JUMAT</option>
                          <option value="Sabtu">SABTU</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label>Jam Mapel Ke - </label>
                        <input type="text" class="form-control" autocomplete="off" name="waktu" placeholder="1 sd 3" required>
                      </div>

                      <div class="form-group">
                        <label>Materi</label>
                        <input type="text" class="form-control" autocomplete="off" name="nama_materi" required>
                      </div>

                      <div class="form-group">
                        <label>Nama Pengajar</label>
                        <input type="text" class="form-control" autocomplete="off" name="nama_pengajar" value="<?= $adm['nama_lengkap']; ?>" readonly>
                      </div>

                      <div class="form-group">
                        <label>MAPEL </label>
                        <input type="text" class="form-control" autocomplete="off" name="mapel" required>
                      </div>


                      <input type="hidden" name="user" value="<?= $adm['id']; ?>" hidden>

                      <div class="modal-footer">
                        <button type="submit" name="simpan" class="btn btn-primary">Save changes</button>
                        <button type="cancel" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      </div>
                    </form>

                  </div>
                </div>
              </div>
            </div>

            <!-- Tabel -->
            <div class="row">
              <div class="table-responsive table--no-card m-b-30 ml-5 mr-5">
                <table id="myTable" class="table table-borderless table-striped table-earning">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Kelas </th>
                      <th>Hari </th>
                      <th>Semester </th>
                      <th>Jam Ke - </th>
                      <th>Mata Pelajaran</th>
                      <th>Materi</th>
                      <th>Nama Pengajar</th>
                      <th>aksi</th>

                    </tr>
                  </thead>

                  <tbody>
                    <?php
                    $no = 1;
                    include 'paging.php';
                    ?>

                  </tbody>
                </table>
              </div>
            </div>

            <script>
              $(document).ready(function() {
                $('#myTable').DataTable();
              });
            </script>
            <!-- end table -->

          </div>
        </div>
      </div>
    </section>

  </div>

</div>
<?php include 'comp/footer.php'; ?>