<?php
require_once '../config/config.php';
global $koneksi;

$id  = $_SESSION['idsppapp'];

$siswa = mysqli_query($koneksi, "SELECT * FROM jurnal WHERE user_upload='$id'");



foreach ($siswa as $pro) :
?>




  <tr>
    <td><?= $no++ ?></td>
    <td><?= $pro['kelas']; ?></td>
    <td><?= $pro['hari']; ?></td>
    <td><?= $pro['semester']; ?></td>
    <td><?= $pro['waktu_jurnal']; ?></td>
    <td><?= $pro['mapel']; ?></td>
    <td><?= $pro['nama_materi']; ?></td>
    <td><?= $pro['nama_guru']; ?></td>


    <td><button class="btn btn-danger" data-toggle="modal" data-target="#hapus_karyawan<?= $pro['id_jurnal']; ?>"><i class="fa fa-trash"></i></button>
      <div class="modal fade" id="hapus_karyawan<?= $pro['id_jurnal']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Apakah anda yakin?</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id_jurnal" value="<?= $pro['id_jurnal']; ?>" hidden>

                <label>Kelas : </label>
                <b><?= $pro['kelas']; ?></b><br>
                <label>Waktu : </label>
                <b><?= $pro['waktu_jurnal']; ?></b><br>
                <label>Mata Pelajaran : </label>
                <b><?= $pro['mapel']; ?></b><br>
                <label>Materi Pembelajaran : </label>
                <b><?= $pro['nama_materi']; ?></b><br>
                <label>Pengajar : </label>
                <b><?= $pro['nama_guru']; ?></b><br>




                <div class="modal-footer">
                  <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
              </form>
            </div>

          </div>
        </div>
      </div>

      <!-- EDIT------------------------------------------------------------------------------------ -->

      <!-- Button trigger modal -->
      <button type="button" class="btn btn-success ml-2" data-toggle="modal" data-target="#editadmin<?= $pro['id_jurnal']; ?>">
        <i class="fa fa-pencil-square-o fa-1x" aria-hidden="true"></i>
      </button>

      <!-- Modal -->
      <div class="modal fade" id="editadmin<?= $pro['id_jurnal']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Edit Data Jurnal</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="" method="POST">
                <input type="hidden" hidden name="id_jurnal" value="<?= $pro['id_jurnal']; ?>">
                <div class="form-group">
                  <label>Kelas </label>
                  <input type="text" class="form-control" autocomplete="off" name="kelas" value="<?= $pro['kelas']; ?>">
                </div>

                <div class="form-group">
                  <label>Semester</label>
                  <input type="text" class="form-control" autocomplete="off" name="semester" value="<?= $pro['semester']; ?>">
                </div>

                <div class="form-group">
                  <label>Hari</label>
                  <input type="text" class="form-control" autocomplete="off" name="hari" value="<?= $pro['hari']; ?>">
                </div>

                <div class=" form-group">
                  <label>Jam Mapel Ke - </label>
                  <input type="text" class="form-control" autocomplete="off" name="waktu" value="<?= $pro['waktu_jurnal']; ?>">
                </div>

                <div class="form-group">
                  <label>Materi</label>
                  <input type="text" class="form-control" autocomplete="off" name="nama_materi" value="<?= $pro['nama_materi']; ?>">
                </div>

                <div class=" form-group">
                  <label>Nama Pengajar</label>
                  <input type="text" class="form-control" autocomplete="off" name="nama_pengajar" value="<?= $pro['nama_guru']; ?>" readonly>
                </div>

                <div class="form-group">
                  <label>MAPEL </label>
                  <input type="text" class="form-control" autocomplete="off" name="mapel" value="<?= $pro['mapel']; ?>">
                </div>


                <input type="hidde" name=" user" value="<?= $adm['id']; ?>" hidden>




                <input type="hidden" name="admin" value="<?= $adm['nama_lengkap']; ?>" hidden>



            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" name="edit" class="btn btn-primary">Save changes</button>
            </div>
            </form>

          </div>
        </div>
      </div>



    </td>

  </tr>
<?php endforeach; ?>