<?php
require_once '../config/config.php';
global $koneksi;

$nama = $adm['nama_lengkap'];
$siswa = mysqli_query($koneksi, "SELECT * FROM jadwalmapel LEFT JOIN guru ON INSTR(guru.mapel, jadwalmapel.kd_mapel) > 0 WHERE nama_guru='$nama' ORDER BY id_jadwalmapel");



foreach ($siswa as $pro) :
?>




  <tr>
    <td><?= $no++ ?></td>
    <td><?= $pro['hari']; ?></td>
    <td><?= $pro['waktu']; ?></td>
    <td><?= $pro['kd_mapel']; ?></td>
    <td><?= $pro['kelas']; ?></td>



  </tr>
<?php endforeach; ?>