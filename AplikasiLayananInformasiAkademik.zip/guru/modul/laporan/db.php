<?php

$host = "localhost";

$user = "root";

$password = "";

$databasename = "simkeg";

$con = mysqli_connect($host, $user, $password, $databasename);
